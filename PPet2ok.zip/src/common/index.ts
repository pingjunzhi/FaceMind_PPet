import config from './config'
export * from './paths'

export { config }
